import { createTransport, Transporter, SendMailOptions } from 'nodemailer';
import ApiError from '../errors/apiError.js';
import { config } from 'dotenv';
import type { INotification } from '../types/types.js';

config();

const GOOGLE_EMAIL = process.env.GOOGLE_EMAIL;
const GOOGLE_APP_PASSWORD = process.env.GOOGLE_APP_PASSWORD;

var transporter: Transporter;

const initializateMailer = async () => {
  try {
    if (!GOOGLE_APP_PASSWORD || !GOOGLE_EMAIL) {
      throw new ApiError('No se encontraron credenciales de email', 500);
    }

    transporter = createTransport({
      service: 'gmail',
      auth: {
        user: GOOGLE_EMAIL,
        pass: GOOGLE_APP_PASSWORD,
      },
    });

    console.log('Nodemailer configurado con constraseña de aplicacion ');
  } catch (error) {
    throw new ApiError(
      `No se pudo configurar Nodemailer -> ${(error as Error).message}`,
      500
    );
  }
};

const sendMail = async (mailOptions: INotification) => {
  if (!transporter) {
    await initializateMailer();
  }

  try {
    const info = await transporter.sendMail({
      from: `Resturante ficticio <${GOOGLE_EMAIL}>`,
      to: mailOptions.recipient,
      subject: mailOptions.subject,
      
    });
  } catch (error) {}
};
